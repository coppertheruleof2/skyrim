/*
BodySlide and Outfit Studio
Copyright (C) 2018  Caliente & ousnius
See the included LICENSE file
*/

#pragma once

struct FBXImportOptions {
	bool InvertU = false;
	bool InvertV = false;
};
